import { Version } from '@fuse/version/version';

export const FUSE_VERSION = new Version('13.6.2').full;
