export type FuseCardFace =
    | 'front'
    | 'back';
